$HystaxConfig = @{
    # -------------------------------
    # VcenterFolder Credentials
    # -------------------------------
    
    VcenterServer = "172.21.71.200"
    VcenterUserName = "administrator@cmp.local"
    VcenterDatastoreName = "Unisys_Cmp"
    VcenterFolderName = "Folder_Gold"

}

