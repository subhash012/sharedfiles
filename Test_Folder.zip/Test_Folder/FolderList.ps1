# ================================
# folders.ps1 – List vCenter VM folders
# ================================

# Load configuration
. (Join-Path $PSScriptRoot "Config\config_hystax.ps1")

function Exit-Json {
    param($Obj, [int]$Code = 0)
    Write-Output ($Obj | ConvertTo-Json -Compress)
    exit $Code
}

try {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

    Connect-VIServer `
        -Server $HystaxConfig.VcenterServer `
        -User $HystaxConfig.VcenterUserName `
        -Password $HystaxConfig.VcenterPassword `
        -ErrorAction Stop | Out-Null

    $folders = Get-Folder -Type VM | Select-Object -ExpandProperty Name

    Disconnect-VIServer -Confirm:$false

    Exit-Json @{
        status  = "success"
        folders = $folders
    }
}
catch {
    Exit-Json @{
        status  = "error"
        message = $_.Exception.Message
    } 1
}
