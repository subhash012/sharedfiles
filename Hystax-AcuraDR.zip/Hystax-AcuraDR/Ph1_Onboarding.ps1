# ==================================================
# Hystax Acura DR – Main Script(phase 1)
# ==================================================

# Load configuration
. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
# . (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")


# ==================================================
# FUNCTION: Initialize-HystaxSession
# ==================================================
function Initialize-HystaxSession {
    # [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [pscredential]$Credential
    )

    Write-Host "[INFO] Initializing Hystax Acura DR session..."

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    try {
        $loginPage = Invoke-WebRequest `
            -Uri "$BaseUrl/login/" `
            -WebSession $session `
            -UseBasicParsing `
            -TimeoutSec 60
    }
    catch {
        throw "[ERROR] Unable to reach Hystax login page. Check TLS / network / proxy. $($_.Exception.Message)"
    }


    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Credential.UserName
        password            = $Credential.GetNetworkCredential().Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "[SUCCESS] Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}
# --------------------------------------------------
# FUNCTION: Invoke-HystaxApiRequest
# --------------------------------------------------
function Invoke-HystaxApiRequest {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [ValidateSet("GET","POST","PUT","DELETE")]
        [string]$Method = "POST",

        [object]$Body
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    try {
        $response = Invoke-WebRequest @params
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Hystax API request failed [$RelativeUrl]: $_"
    }
}

# ==================================================
# FUNCTION: New-HystaxTargetCloud
# ==================================================
function New-HystaxTargetCloud {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [hashtable]$Config,

        [Parameter(Mandatory)]
        [string]$CloudName,

        [Parameter(Mandatory)]
        [string]$VCenterEndpoint,

        [Parameter(Mandatory)]
        [pscredential]$VCenterCredential,

        [Parameter(Mandatory)]
        [string]$EsxiHost,

        [Parameter(Mandatory)]
        [string]$Datastore
    )

    Write-Host "[INFO] Creating target cloud: $CloudName"

    $payload = @{
        csrfmiddlewaretoken   = $Context.CsrfToken
        type                  = $Config.TargetCloudType
        name                  = $CloudName
        endpoint              = $VCenterEndpoint
        username              = $VCenterCredential.UserName
        password              = $VCenterCredential.GetNetworkCredential().Password
        vmware_host           = $EsxiHost
        vmware_datastore      = $Datastore
        mountpoint_variant    = $Config.MountpointVariant
        additional_parameters = $Config.AdditionalParameters
        cloud_form_url        = "/partner/$($Context.PartnerId)/clouds/cloud-add-form/"
    }

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/partner/$($Context.PartnerId)/clouds/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/clouds/"
        } `
        -Body $payload `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    Write-Host "[SUCCESS] Target cloud created successfully"
    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: Get-HystaxClouds
# ==================================================
function Get-HystaxClouds {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching clouds..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/clouds/list/"

    if (-not $result.clouds) {
        Write-Warning "[WARN] No clouds returned from Get-HystaxClouds"
        return @()
    }

    return $result.clouds
}

function Wait-HystaxCloudValidation {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CloudId,

        [Parameter(Mandatory)]
        [hashtable]$Config
    )

    $attempts    = $Config.CloudValidation.Attempts
    $waitSeconds = $Config.CloudValidation.WaitSeconds

    for ($i = 1; $i -le $attempts; $i++) {

        Write-Host "[INFO] Waiting $waitSeconds seconds before checking cloud validation (Attempt $i/$attempts)..."
        Start-Sleep -Seconds $waitSeconds

        $cloud = (Get-HystaxClouds -Context $Context) |
                 Where-Object { $_.id -eq $CloudId }

        if (-not $cloud) {
            throw "[ERROR] Cloud with ID '$CloudId' not found"
        }

        Write-Host "[INFO] Cloud '$($cloud.name)' validation state: $($cloud.validation_state)"

        if ($cloud.validation_state -in @("valid", "validated")) {
            Write-Host "[SUCCESS] Cloud validated successfully"
            return
        }
    }

    throw "[ERROR] Cloud '$CloudId' not validated after $($attempts * $waitSeconds) seconds"
}

# ==================================================
# FUNCTION: Creates New Customer
# ==================================================

function New-HystaxCustomer {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [hashtable]$Config,

        [Parameter(Mandatory)]
        [string]$CustomerName,

        [Parameter(Mandatory)]
        [string]$Email,

        [Parameter(Mandatory)]
        [string]$CloudId
    )

    Write-Host "[INFO] Creating customer: $CustomerName"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken

        name      = $CustomerName
        email     = $Email
        phone     = $Config.Phone
        address   = $Config.Address
        timezone  = $Config.Timezone

        active    = $Config.Active
        cloud     = $CloudId

        is_openstack_cloud = "{`"$CloudId`": false}"
        
        additional_parameters = $Config.AdditionalParameters
        mountpoint_overlay    = $Config.MountpointOverlay
       
    }

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/partner/$($Context.PartnerId)/customer/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/customers/"
        } `
        -Body $payload `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    Write-Host "[SUCCESS] Customer created successfully"
    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: Get-HystaxCustomers
# ==================================================
function Get-HystaxCustomers {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching customers..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/" 

    return $result.customers
}

# ------------------------- main -------------------------
# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# ---------- vCenter Credential ----------
$VCenterSecurePassword = ConvertTo-SecureString `
    $HystaxConfig.VCenterPassword `
    -AsPlainText `
    -Force

$VCenterCredential = New-Object pscredential (
    $HystaxConfig.VCenterUser,
    $VCenterSecurePassword
)


# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential


#Create New Target Cloud 
$newCloud = New-HystaxTargetCloud `
    -Context           $HystaxContext `
    -Config            $HystaxConfig `
    -CloudName         $HystaxConfig.CloudName `
    -VCenterEndpoint   $HystaxConfig.VCenterEndpoint `
    -VCenterCredential $VCenterCredential `
    -EsxiHost          $HystaxConfig.EsxiHost `
    -Datastore         $HystaxConfig.Datastore

$cloudId = $newCloud.id
Write-Host "[INFO] Target Cloud ID: $cloudId"

# cloud validation
Wait-HystaxCloudValidation `
    -Context $HystaxContext `
    -CloudId $cloudId `
    -Config $HystaxConfig


#Get Hystax Clouds
$clouds = Get-HystaxClouds -Context $HystaxContext
$clouds | Format-Table -AutoSize

#Customer Creation
$newCustomer = New-HystaxCustomer `
    -Context      $HystaxContext `
    -Config       $HystaxConfig `
    -CustomerName $HystaxConfig.customer_name `
    -Email        $HystaxConfig.customer_email `
    -CloudId      $cloudId

# List customers
$customers = Get-HystaxCustomers -Context $HystaxContext
$customers | Format-Table -AutoSize

