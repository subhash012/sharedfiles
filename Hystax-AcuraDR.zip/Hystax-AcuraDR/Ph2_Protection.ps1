# ==================================================
# Hystax Acura DR – Main Script(phase 2)
# ==================================================

. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
# . (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")

# ==================================================
# FUNCTION: Initialize-HystaxSession
# ==================================================
function Initialize-HystaxSession {
    # [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [pscredential]$Credential
    )

    Write-Host "[INFO] Initializing Hystax Acura DR session..."

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    try {
        $loginPage = Invoke-WebRequest `
            -Uri "$BaseUrl/login/" `
            -WebSession $session `
            -UseBasicParsing `
            -TimeoutSec 60
    }
    catch {
        throw "[ERROR] Unable to reach Hystax login page. Check TLS / network / proxy. $($_.Exception.Message)"
    }


    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Credential.UserName
        password            = $Credential.GetNetworkCredential().Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "[SUCCESS] Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}
# --------------------------------------------------
# FUNCTION: Invoke-HystaxApiRequest
# --------------------------------------------------
function Invoke-HystaxApiRequest {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [ValidateSet("GET","POST","PUT","DELETE")]
        [string]$Method = "POST",

        [object]$Body
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    try {
        $response = Invoke-WebRequest @params
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Hystax API request failed [$RelativeUrl]: $_"
    }
}

# ==================================================
# FUNCTION: Get-HystaxCustomers
# ==================================================
function Get-HystaxCustomers {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching customers..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/" 

    return $result.customers
}

# ---------- FUNCTION: Get Hystax Customer ID ----------
function Get-HystaxCustomerId {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerName
    )

    Write-Host "[INFO] Fetching customer ID for customer name: '$CustomerName'"

    $customer = Get-HystaxCustomers -Context $Context |
                Where-Object { $_.customer_name -eq $CustomerName } |
                Select-Object -First 1

    if (-not $customer) {
        throw "Customer '$CustomerName' not found"
    }

    Write-Host "[INFO] Customer '$CustomerName' resolved with ID: $($customer.customer_id)"

    return $customer.customer_id
}

# ==================================================
# FUNCTION: Create Machine Group
# ==================================================
# ---------- FUNCTION: Create Hystax Machine Group ----------
function New-HystaxMachineGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName,

        [string]$Description
    )

    Write-Host "[INFO] Creating machine group '$GroupName' for customer $CustomerId..."

    $relativeUrl = "/customer/$CustomerId/group/add/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $GroupName
        description         = $Description
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        if (-not $response.Content) {
            throw "Empty response received while creating machine group"
        }

        $group = $response.Content | ConvertFrom-Json

        if (-not $group.id) {
            throw "Machine group ID not found in response"
        }

        Write-Host "[INFO] Machine group '$GroupName' created with ID: $($group.id)"

        return $group.id
    }
    catch {
        throw "Failed to create machine group '$GroupName': $($_.Exception.Message)"
    }
}


# ==================================================
# FUNCTION: Wait-HystaxMachineGroupCreation
# Purpose : Simple wait after machine group creation
# ==================================================
function Wait-HystaxMachineGroupCreation {
    param (
        [Parameter(Mandatory)]
        [int]$WaitSeconds
    )

    Write-Host "[INFO] Waiting for machine group creation..."
    Start-Sleep -Seconds $WaitSeconds
    Write-Host "[SUCCESS] Machine group created successfully"
}

# ==================================================
# FUNCTION: Get-HystaxMachineGroups
# Purpose : List machine groups for a customer
# ==================================================
function Get-HystaxMachineGroups {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching machine groups for customer: $CustomerId"

    $relativeUrl = "/customer/$CustomerId/group/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Failed to list machine groups for customer '$CustomerId': $($_.Exception.Message)"
    }
}

# ==================================================
# FUNCTION: Get-HystaxMachines
# Purpose : List machines (VMs) from a machine group
# ==================================================
function Get-HystaxMachines {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId
    )

    Write-Host "[INFO] Fetching machines for group $MachineGroupId ..."

    $relativeUrl = "/customer/$CustomerId/group/$MachineGroupId/machines/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        $result = $response.Content | ConvertFrom-Json

        if (-not $result.machines) {
            Write-Host "[WARN] No machines found in this group"
            return @()
        }

        return $result.machines
    }
    catch {
        throw "Failed to list machines: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Get Hystax Machine IDs by Machine Names (Non-blocking) ----------
function Get-HystaxMachineIdsByNames {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineNames
    )

    Write-Host "[INFO] Fetching machines for group ID: $MachineGroupId"

    $machines = Get-HystaxMachines `
        -Context $Context `
        -CustomerId $CustomerId `
        -MachineGroupId $MachineGroupId

    if (-not $machines -or $machines.Count -eq 0) {
        Write-Warning "No machines found in group '$MachineGroupId'"
        return @()
    }

    $machineIds = @()
    $notFound   = @()

    foreach ($name in $MachineNames) {
        $machine = $machines |
                   Where-Object { $_.name -eq $name } |
                   Select-Object -First 1

        if ($machine) {
            Write-Host "[INFO] Found VM '$name' → ID: $($machine.id)"
            $machineIds += $machine.id
        }
        else {
            $notFound += $name
        }
    }

    if ($notFound.Count -gt 0) {
        Write-Warning "[WARN] The following VMs were NOT found in group '$MachineGroupId':"
        $notFound | ForEach-Object { Write-Warning "  - $_" }
    }

    if ($machineIds.Count -eq 0) {
        Write-Warning "[WARN] No valid machines resolved. Returning empty list."
    }

    return $machineIds
}


# ---------- FUNCTION: Get Hystax Machine Group ID ----------
function Get-HystaxMachineGroupId {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName
    )

    Write-Host "[INFO] Resolving machine group ID for group name: '$GroupName'"

    $groups = Get-HystaxMachineGroups `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $groups) {
        throw "No machine groups returned for customer '$CustomerId'"
    }

    $group = $groups |
             Where-Object { $_.name -eq $GroupName } |
             Select-Object -First 1

    if (-not $group) {
        throw "Machine group '$GroupName' not found for customer '$CustomerId'"
    }

    Write-Host "[INFO] Machine group '$GroupName' resolved with ID: $($group.id)"

    return $group.id
}

# ==================================================
# FUNCTION: Move-HystaxMachineToGroup
# Purpose : Move a single VM to a machine group
# ==================================================
function Move-HystaxMachineToGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [Parameter(Mandatory)]
        [string]$TargetGroupId
    )

    Write-Host "[INFO] Moving machine '$MachineId' to group '$TargetGroupId'..."

    $relativeUrl = "/machine/$MachineId/move/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        group               = $TargetGroupId
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing
    }
    catch {
        throw "Failed to move machine '$MachineId': $($_.Exception.Message)"
    }
}

# ==================================================
# FUNCTION: Wait-HystaxMachineMove
# Purpose : Wait for machine move to reflect in UI
# ==================================================
function Wait-HystaxMachineMove {
    param (
        [Parameter(Mandatory)]
        [int]$WaitSeconds
    )

    Write-Host "[INFO] Waiting for machine move to complete..."
    Start-Sleep -Seconds $WaitSeconds
    Write-Host "[SUCCESS] Machines moved Successfully"
}

# ==================================================
# FUNCTION: Move Multiple VMs to a Group
# ==================================================
function Move-HystaxMachinesToGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$TargetGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineIds
    )

    Write-Host "[INFO] Starting bulk move of $($MachineIds.Count) machine(s)..."

    foreach ($machineId in $MachineIds) {
        try {
            Move-HystaxMachineToGroup `
                -Context $Context `
                -MachineId $machineId `
                -TargetGroupId $TargetGroupId
        }
        catch {
            throw "[ERROR] Bulk move failed for machine $machineId : $($_.Exception.Message)"
        }
    }
}

function Start-HystaxMachineProtection {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [switch]$ForceFullReplication
    )

    Write-Host "[INFO] Starting protection for machine '$MachineId'..."

    $relativeUrl = "/machine/$MachineId/unpark/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
    }

    if ($ForceFullReplication.IsPresent) {
        $payload["force_full"] = "true"
        Write-Host "[WARN] Force full replication enabled"
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "[SUCCESS] Protection started successfully"
    }
    catch {
        throw "Failed to start protection for machine ${MachineId}: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Start Protection for Multiple Machines ----------
function Start-HystaxMachinesProtection {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string[]]$MachineIds,

        [switch]$ForceFullReplication
    )

    Write-Host "[INFO] Starting protection for $($MachineIds.Count) machine(s)..."

    $failedMachines = @()

    foreach ($machineId in $MachineIds) {
        try {
            if ($ForceFullReplication.IsPresent) {
                Start-HystaxMachineProtection `
                    -Context $Context `
                    -MachineId $machineId `
                    -ForceFullReplication
            }
            else {
                Start-HystaxMachineProtection `
                    -Context $Context `
                    -MachineId $machineId
            }
            Start-Sleep -Seconds 20
        }
        catch {
            Write-Warning "[WARN] Failed to start protection for machine $machineId"
            Write-Warning $_.Exception.Message
            $failedMachines += $machineId
        }
    }

    if ($failedMachines.Count -gt 0) {
        Write-Warning "[SUMMARY] Protection failed for the following machines:"
        $failedMachines | ForEach-Object { Write-Warning "  - $_" }
    }
    else {
        Write-Host "[SUCCESS] Protection started successfully for all machines"
    }

    return @{
        TotalRequested = $MachineIds.Count
        FailedMachines = $failedMachines
        Successful     = $MachineIds.Count - $failedMachines.Count
    }
}

# ---------- FUNCTION: Wait for Hystax Machines Protection ----------
function Wait-HystaxMachinesProtection {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineIds,

        [int]$PollIntervalMinutes = 5,

        [int]$MaxWaitMinutes = 720   # 12 hours safety cap
    )

    Write-Host "[INFO] Waiting for machines to reach terminal state (Protected / Parked)..."
    Write-Host "[INFO] Poll interval: $PollIntervalMinutes minutes"
    Write-Host "[INFO] Max wait time: $MaxWaitMinutes minutes"

    $elapsedMinutes = 0
    $terminalStates = @("protected", "parked")

    while ($true) {

        Write-Host "`n[INFO] Polling machine status (Elapsed: $elapsedMinutes min)..."

        $machines = Get-HystaxMachines `
            -Context $Context `
            -CustomerId $CustomerId `
            -MachineGroupId $MachineGroupId

        # Filter only machines we care about
        $trackedMachines = $machines |
                           Where-Object { $MachineIds -contains $_.id }

        if (-not $trackedMachines -or $trackedMachines.Count -eq 0) {
            Write-Warning "[WARN] None of the tracked machines found in group"
            break
        }

        $pending = @()

        foreach ($machine in $trackedMachines) {

            $state = $machine.status_level.ToLower()
            $progress = if ($machine.progress) { "$($machine.progress)%" } else { "N/A" }

            Write-Host (" - {0,-25} | State: {1,-12} | Progress: {2}" -f `
                $machine.name, $state, $progress)

            if ($terminalStates -notcontains $state) {
                $pending += $machine
            }
        }

        if ($pending.Count -eq 0) {
            Write-Host "`n[SUCCESS] All machines reached terminal state"
            return @{
                Status = "Completed"
                Machines = $trackedMachines
            }
        }

        if ($elapsedMinutes -ge $MaxWaitMinutes) {
            Write-Warning "[TIMEOUT] Maximum wait time reached"
            return @{
                Status = "TimedOut"
                PendingMachines = $pending
            }
        }

        Write-Host "[INFO] Waiting $PollIntervalMinutes minutes before next check..."
        Start-Sleep -Seconds ($PollIntervalMinutes * 60)
        $elapsedMinutes += $PollIntervalMinutes
    }
}

# ------------------------------ main -------------------------------
# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential

#fetching customer id
$customer_id = Get-HystaxCustomerId `
    -Context $HystaxContext `
    -CustomerName $HystaxConfig.customer_name

# Create Machine Group
$MachineGroupId = New-HystaxMachineGroup `
    -Context     $HystaxContext `
    -CustomerId  $customer_id `
    -GroupName   $HystaxConfig.MachineGroupName `
    -Description $HystaxConfig.MachineGroupDescription

Wait-HystaxMachineGroupCreation -WaitSeconds 10

# List MachineGroups 
$groups = Get-HystaxMachineGroups `
    -Context $HystaxContext `
    -CustomerId $customer_id

$groups |
Select-Object `
    @{ Name = "id"; Expression = { $_.id } },
    @{ Name = "name"; Expression = { $_.name } },
    @{ Name = "description"; Expression = { $_.description } } |
Format-Table -AutoSize

#getting machine ids
$groupId = Get-HystaxMachineGroupId `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -GroupName "Default"

$machineIds = Get-HystaxMachineIdsByNames `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -MachineGroupId $groupId `
    -MachineNames $HystaxConfig.machineNames

# Move multiple machines to target group
Move-HystaxMachinesToGroup `
    -Context $HystaxContext `
    -TargetGroupId $MachineGroupId `
    -MachineIds $machineIds

# Optional wait
Wait-HystaxMachineMove -WaitSeconds 20

$result = Start-HystaxMachinesProtection `
    -Context $HystaxContext `
    -MachineIds $machineIds

# Wait for completion
$result = Wait-HystaxMachinesProtection `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -MachineGroupId $MachineGroupId `
    -MachineIds $machineIds `
    -PollIntervalMinutes 5            