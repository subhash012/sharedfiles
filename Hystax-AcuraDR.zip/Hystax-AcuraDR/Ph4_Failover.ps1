# ==================================================
# Hystax Acura DR – Main Script(phase 4)
# ==================================================

. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
# . (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")

# ==================================================
# FUNCTION: Initialize-HystaxSession
# ==================================================
function Initialize-HystaxSession {
    # [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [pscredential]$Credential
    )

    Write-Host "[INFO] Initializing Hystax Acura DR session..."

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    try {
        $loginPage = Invoke-WebRequest `
            -Uri "$BaseUrl/login/" `
            -WebSession $session `
            -UseBasicParsing `
            -TimeoutSec 60
    }
    catch {
        throw "[ERROR] Unable to reach Hystax login page. Check TLS / network / proxy. $($_.Exception.Message)"
    }


    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Credential.UserName
        password            = $Credential.GetNetworkCredential().Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "[SUCCESS] Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}
# --------------------------------------------------
# FUNCTION: Invoke-HystaxApiRequest
# --------------------------------------------------
function Invoke-HystaxApiRequest {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [ValidateSet("GET","POST","PUT","DELETE")]
        [string]$Method = "POST",

        [object]$Body
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    try {
        $response = Invoke-WebRequest @params
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Hystax API request failed [$RelativeUrl]: $_"
    }
}

# ==================================================
# FUNCTION: Get-HystaxCustomers
# ==================================================
function Get-HystaxCustomers {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching customers..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/" 

    return $result.customers
}

# ---------- FUNCTION: Get Hystax Customer ID ----------
function Get-HystaxCustomerId {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerName
    )

    Write-Host "[INFO] Fetching customer ID for customer name: '$CustomerName'"

    $customer = Get-HystaxCustomers -Context $Context |
                Where-Object { $_.customer_name -eq $CustomerName } |
                Select-Object -First 1

    if (-not $customer) {
        throw "Customer '$CustomerName' not found"
    }

    Write-Host "[INFO] Customer '$CustomerName' resolved with ID: $($customer.customer_id)"

    return $customer.customer_id
}


# ==================================================
# FUNCTION: Get-HystaxDRPlans
# Purpose : List DR plans for a customer
# ==================================================
function Get-HystaxDRPlans {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching DR plans for customer $CustomerId..."

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/list/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing

    return ($response.Content | ConvertFrom-Json)
}


# -------------------------------
# FUNCTION:  Failover /  Recovery
# -------------------------------
function Invoke-HystaxRecoveryWorkflow {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$DRPlanName,

        [Parameter(Mandatory)]
        [string]$CloudSiteName,

        [switch]$TestRecovery,
        [switch]$Confirm
    )

    if (-not $Confirm) {
        throw "Recovery execution requires explicit -Confirm flag"
    }

    Write-Host "=============================================="
    Write-Host " HYSTAX RECOVERY WORKFLOW STARTED"
    Write-Host "Customer ID : $CustomerId"
    Write-Host "DR Plan     : $DRPlanName"
    Write-Host "Cloud Site  : $CloudSiteName"
    Write-Host "Mode        : $(if ($TestRecovery) { 'TEST RECOVERY' } else { 'FAILOVER' })"
    Write-Host "=============================================="

    # ------------------------------------------------------------
    # STEP 1: Fetch DR Plans
    # ------------------------------------------------------------
    Write-Host "Fetching DR plans..."
    $drPlansResponse = Get-HystaxDRPlans `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $drPlansResponse.plans) {
        throw "No DR plans returned for customer $CustomerId"
    }

    # ------------------------------------------------------------
    # STEP 2: Select DR Plan
    # ------------------------------------------------------------
    $drPlan = $drPlansResponse.plans |
              Where-Object { $_.name -eq $DRPlanName } |
              Select-Object -First 1

    if (-not $drPlan) {
        throw "DR plan '$DRPlanName' not found"
    }

    if (-not $drPlan.plan) {
        throw "Plan JSON missing for DR plan '$DRPlanName'"
    }

    Write-Host "Selected DR plan ID:" $drPlan.id

    # ------------------------------------------------------------
    # STEP 3: Deserialize Final Plan
    # ------------------------------------------------------------
    Write-Host "Deserializing DR plan..."
    $finalPlan = $drPlan.plan | ConvertFrom-Json

    # ------------------------------------------------------------
    # STEP 4: Print Final Plan (Verification)
    # ------------------------------------------------------------
    Write-Host "===== FINAL DR PLAN (JSON) ====="
    $finalPlan | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 5: Generate Recovery Timestamp (UTC Epoch)
    # ------------------------------------------------------------
    $timestamp = [int][double]::Parse((Get-Date -UFormat %s))
    Write-Host "Generated recovery timestamp:" $timestamp

    # ------------------------------------------------------------
    # STEP 6: Build Run Recovery Payload
    # ------------------------------------------------------------
    $payload = @{
        name             = $CloudSiteName
        customer_id      = $CustomerId
        timestamp        = $timestamp
        testsiterecovery = $(if ($TestRecovery) { "true" } else { "" })
        plan             = $finalPlan
    }

    Write-Host "===== RUN RECOVERY PAYLOAD ====="
    $payload | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 7: Execute Run Recovery (FORM POST, NOT JSON)
    # ------------------------------------------------------------
    Write-Host " Executing Run Recovery (form-based)..."

    $formBody = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $CloudSiteName
        customer_id         = $CustomerId
        timestamp           = $timestamp
        testsiterecovery    = $(if ($TestRecovery) { "true" } else { "" })
        plan                = ($finalPlan | ConvertTo-Json -Depth 15)
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)/ajax/run_recover/" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/recover_step_three/"
            } `
            -Body $formBody `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host " Run Recovery request submitted successfully"
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw " Recovery execution failed: $($_.Exception.Message)"
    }
}

# --------------------------- main --------------------------------
# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)


# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential

#fetching customer id
$customer_id = Get-HystaxCustomerId `
    -Context $HystaxContext `
    -CustomerName $HystaxConfig.customer_name

#Failover
Invoke-HystaxRecoveryWorkflow `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -DRPlanName $HystaxConfig.DRPlanName `
    -CloudSiteName "auto-failover-cloudsite-$(Get-Date -Format yyyyMMddHHmmss)" `
    -Confirm