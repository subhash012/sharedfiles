# ==================================================
# Hystax Acura DR – Main Script(phase 3)
# ==================================================

. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
# . (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")

# ==================================================
# FUNCTION: Initialize-HystaxSession
# ==================================================
function Initialize-HystaxSession {
    # [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [pscredential]$Credential
    )

    Write-Host "[INFO] Initializing Hystax Acura DR session..."

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    try {
        $loginPage = Invoke-WebRequest `
            -Uri "$BaseUrl/login/" `
            -WebSession $session `
            -UseBasicParsing `
            -TimeoutSec 60
    }
    catch {
        throw "[ERROR] Unable to reach Hystax login page. Check TLS / network / proxy. $($_.Exception.Message)"
    }


    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Credential.UserName
        password            = $Credential.GetNetworkCredential().Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "[SUCCESS] Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}
# --------------------------------------------------
# FUNCTION: Invoke-HystaxApiRequest
# --------------------------------------------------
function Invoke-HystaxApiRequest {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [ValidateSet("GET","POST","PUT","DELETE")]
        [string]$Method = "POST",

        [object]$Body
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    try {
        $response = Invoke-WebRequest @params
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Hystax API request failed [$RelativeUrl]: $_"
    }
}

# ==================================================
# FUNCTION: Get-HystaxCustomers
# ==================================================
function Get-HystaxCustomers {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching customers..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/" 

    return $result.customers
}

# ---------- FUNCTION: Get Hystax Customer ID ----------
function Get-HystaxCustomerId {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerName
    )

    Write-Host "[INFO] Fetching customer ID for customer name: '$CustomerName'"

    $customer = Get-HystaxCustomers -Context $Context |
                Where-Object { $_.customer_name -eq $CustomerName } |
                Select-Object -First 1

    if (-not $customer) {
        throw "Customer '$CustomerName' not found"
    }

    Write-Host "[INFO] Customer '$CustomerName' resolved with ID: $($customer.customer_id)"

    return $customer.customer_id
}

# ==================================================
# FUNCTION: Get-HystaxMachineGroups
# Purpose : List machine groups for a customer
# ==================================================
function Get-HystaxMachineGroups {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching machine groups for customer: $CustomerId"

    $relativeUrl = "/customer/$CustomerId/group/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Failed to list machine groups for customer '$CustomerId': $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Get Hystax Machine Group ID ----------
function Get-HystaxMachineGroupId {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName
    )

    Write-Host "[INFO] Resolving machine group ID for group name: '$GroupName'"

    $groups = Get-HystaxMachineGroups `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $groups) {
        throw "No machine groups returned for customer '$CustomerId'"
    }

    $group = $groups |
             Where-Object { $_.name -eq $GroupName } |
             Select-Object -First 1

    if (-not $group) {
        throw "Machine group '$GroupName' not found for customer '$CustomerId'"
    }

    Write-Host "[INFO] Machine group '$GroupName' resolved with ID: $($group.id)"

    return $group.id
}

function Get-HystaxMachines {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId
    )

    Write-Host "[INFO] Fetching machines for group $MachineGroupId ..."

    $relativeUrl = "/customer/$CustomerId/group/$MachineGroupId/machines/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        $result = $response.Content | ConvertFrom-Json

        if (-not $result.machines) {
            Write-Host "[WARN] No machines found in this group"
            return @()
        }

        return $result.machines
    }
    catch {
        throw "Failed to list machines: $($_.Exception.Message)"
    }
}

# ==================================================
# FUNCTION: Get-HystaxDRPlans
# Purpose : List DR plans for a customer
# ==================================================
function Get-HystaxDRPlans {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching DR plans for customer $CustomerId..."

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/list/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing

    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: New-HystaxDRPlan (Template creation)
# ==================================================
function New-HystaxDRPlan {
    [CmdletBinding()]
    param (
        [hashtable]$Context,
        [string]$CustomerId,
        [string]$PlanName
    )

    Write-Host "[INFO] Creating DR plan template '$PlanName'..."

    Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/template/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Body @{
            csrfmiddlewaretoken = $Context.CsrfToken
            plan_name           = $PlanName
        } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing | Out-Null
}

# ==================================================
# FUNCTION: Create-HystaxDRPlan (DR Plan Creation)
# ==================================================
function Create-HystaxDRPlan {
    [CmdletBinding()]
    param (
        [hashtable]$Context,
        [string]$CustomerId,
        [string]$PlanName,
        [string]$PlanJson,
        [string]$AllPlansJson,
        [string]$GroupsJson,
        [string]$CloudType
    )

    Write-Host "[INFO] Creating DR plan '$PlanName'..."

    Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/create/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
        } `
        -Body @{
            csrfmiddlewaretoken = $Context.CsrfToken
            plan_name           = $PlanName
            plan                = $PlanJson
            all_plans           = $AllPlansJson
            groups              = $GroupsJson
            cloud_type          = $CloudType
        } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing | Out-Null

    Write-Host "[SUCCESS] DR plan created successfully"
}


# --------------------------- main --------------------------------
# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential


#fetching customer id
$customerId = Get-HystaxCustomerId `
    -Context $HystaxContext `
    -CustomerName $HystaxConfig.customer_name


$groupId = Get-HystaxMachineGroupId `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -GroupName $HystaxConfig.MachineGroupName


$machines = Get-HystaxMachines `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -MachineGroupId $groupId

if (-not $machines -or $machines.Count -eq 0) {
    throw "[ERROR] No machines found in machine group '$($HystaxConfig.MachineGroupName)'"
}

# --------------------------------------------------
# Build PLAN JSON
# --------------------------------------------------
$devices = @{}
$rank = 0

foreach ($m in $machines) {
    $devices[$m.name] = @{
        id     = $m.id
        flavor = $HystaxConfig.Flavor
        rank   = $rank
        ports  = @(
            @{
                name   = "port_0"
                subnet = $HystaxConfig.CloudSubnetName
            }
        )
    }
    $rank++
}

$planJson = @{
    devices = $devices
    subnets = @{
        $HystaxConfig.CloudSubnetName = @{
            name      = $HystaxConfig.CloudSubnetName
            subnet_id = $HystaxConfig.CloudSubnetName
            cidr      = $HystaxConfig.CloudSubnetCIDR
        }
    }
} | ConvertTo-Json -Depth 15 -Compress


# --------------------------------------------------
# Build ALL_PLANS
# --------------------------------------------------
$allPlansJson = @{
    devices = $devices
    subnets = @{
        subnet_0 = @{
            cidr = $HystaxConfig.CloudSubnetCIDR
        }
    }
} | ConvertTo-Json -Depth 10 -Compress

# --------------------------------------------------
# Build GROUPS
# --------------------------------------------------
$groupsJson = @(
    @{
        id          = $groupId
        customer_id = $customerId
        name        = $HystaxConfig.MachineGroupName
        machines    = $machines.id
    }
) | ConvertTo-Json -Depth 10 -Compress


# --------------------------------------------------
# Create DR Plan
# --------------------------------------------------
New-HystaxDRPlan `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -PlanName $HystaxConfig.DRPlanName

Create-HystaxDRPlan `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -PlanName $HystaxConfig.DRPlanName `
    -PlanJson $planJson `
    -AllPlansJson $allPlansJson `
    -GroupsJson $groupsJson `
    -CloudType $HystaxConfig.DRPlanCloudType

Write-Host "`n===== PHASE 3 COMPLETED ====="
Write-Host "⏸ DR plan created. Failover execution is a separate controlled step."
 