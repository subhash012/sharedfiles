############################################################
# Hystax UI Automation – Base Functions
# Single PS1 Script with reusable functions
############################################################

# ---------- GLOBAL SETTINGS ----------
$Global:HystaxContext = $null

# ---------- FUNCTION: Initialize Session ----------
function Initialize-HystaxSession {
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [string]$Username,

        [Parameter(Mandatory)]
        [string]$Password

    )

    Write-Host "Initializing Hystax session..."

    # Enforce TLS 1.2
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    # Ignore SSL cert errors (self-signed)
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    # Create browser-like session
    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    # Load login page
    $loginPage = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -WebSession $session `
        -UseBasicParsing

    # Extract CSRF token
    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    # Submit login form
    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Username
        password            = $Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -ContentType "application/x-www-form-urlencoded" `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "Authentication successful"

    # Return context object
    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}

# ---------- FUNCTION: Invoke Hystax UI Request ----------
function Invoke-HystaxRequest {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [string]$Method = "POST",

        [object]$Body = $null
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"           = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    $response = Invoke-WebRequest @params
    return ($response.Content | ConvertFrom-Json)
}

# ---------- FUNCTION: Get Customers ----------
function Get-HystaxCustomers {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "Fetching customers..."

    $result = Invoke-HystaxRequest `
        -Context $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/"

    return $result.customers
}

# ---------- FUNCTION: Get Clouds ----------
function Get-HystaxClouds {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "Fetching clouds..."

    $result = Invoke-HystaxRequest `
        -Context $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/clouds/list/"

    return $result
}

# ---------- FUNCTION: Create Target Cloud ---------- #
function New-HystaxTargetCloud {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CloudName,

        [Parameter(Mandatory)]
        [string]$VCenterEndpoint,

        [Parameter(Mandatory)]
        [string]$VCenterUsername,

        [Parameter(Mandatory)]
        [string]$VCenterPassword,

        [Parameter(Mandatory)]
        [string]$EsxiHost,

        [Parameter(Mandatory)]
        [string]$Datastore
    )

    Write-Host "Creating target cloud '$CloudName'..."

    $relativeUrl = "/partner/$($Context.PartnerId)/clouds/add/"

    # EXACT UI payload
    $payload = @{
        csrfmiddlewaretoken     = $Context.CsrfToken
        type                    = "vmware_cnr"
        name                    = $CloudName
        endpoint                = $VCenterEndpoint
        username                = $VCenterUsername
        password                = $VCenterPassword

        vmware_host             = $EsxiHost
        vmware_datastore        = $Datastore

        mountpoint_variant      = "mp_cloud_agent"
        custom_mountpoint       = ""

        s3_host                 = ""
        s3_port                 = ""
        s3_access_key_id        = ""
        s3_secret_access_key    = ""
        s3_bucket               = ""

        nfs_host                = ""
        nfs_path                = ""

        smb_host                = ""
        smb_path                = ""
        smb_username            = ""
        smb_password            = ""

        vcd_host                = ""
        vcd_user                = ""
        vcd_password            = ""
        vcd_org                 = ""
        vcd_vdc                 = ""
        vcd_vapp                = ""

        additional_parameters   = "{}"
        cloud_form_url          = "/partner/$($Context.PartnerId)/clouds/cloud-add-form/"
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/clouds/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "Target cloud created successfully"
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Target cloud creation failed: $($_.Exception.Message)"
    }
}

# # ---------- FUNCTION: Wait for Target Cloud Validation ----------
# function Wait-ForCloudValidation {
#     param (
#         [Parameter(Mandatory)]
#         [hashtable]$Context,

#         [Parameter(Mandatory)]
#         [string]$CloudId,

#         [int]$TimeoutSeconds = 120,
#         [int]$PollIntervalSeconds = 10
#     )

#     Write-Host "Waiting for target cloud validation (CloudId: $CloudId)..."

#     $elapsed = 0

#     while ($elapsed -lt $TimeoutSeconds) {

#         $cloud = Get-HystaxClouds -Context $Context | Where-Object id -eq $CloudId

#         if (-not $cloud) {
#             throw "Cloud with ID $CloudId not found"
#         }

#         Write-Host "Current validation state:" $cloud.validation_state

#         switch ($cloud.validation_state) {
#             "validated" {
#                 Write-Host " Target cloud validated successfully"
#                 return $cloud
#             }
#             "failed" {
#                 throw " Target cloud validation failed"
#             }
#         }

#         Start-Sleep -Seconds $PollIntervalSeconds
#         $elapsed += $PollIntervalSeconds
#     }

#     throw " Timeout waiting for cloud validation (waited $TimeoutSeconds seconds)"
# }

# ---------- FUNCTION: Wait 10 Seconds ----------
# function Wait-ForCloudValidation {
#     param ([hashtable]$Context,[string]$CloudId)
 
#     Write-Host "Waiting 10 seconds for cloud validation..."
#     Start-Sleep -Seconds 10
 
#     $cloud = (Get-HystaxClouds -Context $Context | Where-Object id -eq $CloudId)
#     if ($cloud) {
#         Write-Host "Validation state:" $cloud.validation_state
#     }
 
#     return $cloud
# }

#............ create hystax customer ..........
function New-HystaxCustomer {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerName,

        [Parameter(Mandatory)]
        [string]$Email,

        [Parameter(Mandatory)]
        [string]$CloudId,   # UUID from target cloud

        [string]$Phone = "",
        [string]$Address = "",
        [string]$Timezone = "UTC"
    )

    Write-Host "Creating customer '$CustomerName'..."

    $relativeUrl = "/partner/$($Context.PartnerId)/customer/add/"

    # EXACT UI payload
    $payload = @{
        csrfmiddlewaretoken                 = $Context.CsrfToken

        name                                = $CustomerName
        email                               = $Email
        phone                               = $Phone
        address                             = $Address
        timezone                            = $Timezone

        active                              = "on"
        cloud                               = $CloudId

        is_openstack_cloud                  = "{`"$CloudId`": false}"

        project_id                          = ""
        replication_endpoint_ip             = ""
        replication_endpoint_certificate    = ""
        replication_endpoint_port           = ""
        replication_logstash_ip             = ""
        replication_logstash_port           = ""

        additional_parameters               = ""
        mountpoint_overlay                  = ""
    }

    # DEBUG (recommended for first run)
    Write-Host "DEBUG: Customer payload"
    $payload.GetEnumerator() | Format-Table -AutoSize

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/customers/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "Customer created successfully"
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Customer creation failed: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: List Machine Groups ----------
function Get-HystaxMachineGroups {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "Fetching machine groups for customer $CustomerId..."

    $relativeUrl = "/customer/$CustomerId/group/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        # IMPORTANT: response is already an array
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Failed to list machine groups: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: List Machines (VMs) ----------
function Get-HystaxMachines {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId
    )

    Write-Host "Fetching machines for group $MachineGroupId..."

    $relativeUrl = "/customer/$CustomerId/group/$MachineGroupId/machines/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        # Response is a JSON array
        $result = $response.Content | ConvertFrom-Json
        return $result.machines

    }
    catch {
        throw "Failed to list machines: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Create Machine Group ----------
function New-HystaxMachineGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName,

        [string]$Description = ""
    )

    Write-Host "Creating machine group '$GroupName' for customer $CustomerId..."

    $relativeUrl = "/customer/$CustomerId/group/add/"

    # Payload exactly as UI sends
    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $GroupName
        description         = $Description
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "Machine group created successfully"

        # Some versions return JSON, some return empty response
        if ($response.Content) {
            return ($response.Content | ConvertFrom-Json)
        }
    }
    catch {
        throw "Failed to create machine group: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Move Single VM to a New Group ----------
function Move-HystaxMachineToGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [Parameter(Mandatory)]
        [string]$TargetGroupId
    )

    Write-Host "Moving machine '$MachineId' to group '$TargetGroupId'..."

    $relativeUrl = "/machine/$MachineId/move/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        group               = $TargetGroupId
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "✅ Machine moved successfully"
    }
    catch {
        throw "❌ Failed to move machine ${MachineId}: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Move Multiple VMs to a Group ----------
function Move-HystaxMachinesToGroup {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$TargetGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineIds
    )

    Write-Host "Starting bulk move of $($MachineIds.Count) machine(s)..."

    foreach ($machineId in $MachineIds) {
        try {
            Move-HystaxMachineToGroup `
                -Context $Context `
                -MachineId $machineId `
                -TargetGroupId $TargetGroupId
        }
        catch {
            throw "Bulk move stopped. Failed on machine ${machineId}: $($_.Exception.Message)"
        }
    }

    Write-Host " All machines moved successfully"
}

# ---------- FUNCTION: Start Protection (Unpark Machine) ----------
function Start-HystaxMachineProtection {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [switch]$ForceFullReplication
    )

    Write-Host "Starting protection for machine '$MachineId'..."

    $relativeUrl = "/machine/$MachineId/unpark/"

    # Base payload
    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
    }

    # Optional: force full replication
    if ($ForceFullReplication.IsPresent) {
        $payload["force_full"] = "true"
        Write-Host "⚠ Force full replication enabled"
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "Protection started successfully (replication initiated)"
    }
    catch {
        throw " Failed to start protection for machine ${MachineId}: $($_.Exception.Message)"
    }
}

#................. list DR Plans ...................
function Get-HystaxDRPlans {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$CustomerId
    )
 
    Write-Host "Fetching DR plans for customer $CustomerId..."
 
    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/list/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing
 
    return ($response.Content | ConvertFrom-Json)
}

# ---------- MAIN FUNCTION: End-to-End Hystax Recovery ----------
function Invoke-HystaxRecoveryWorkflow {
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$DRPlanName,

        [Parameter(Mandatory)]
        [string]$CloudSiteName,

        [switch]$TestRecovery,
        [switch]$Confirm
    )

    if (-not $Confirm) {
        throw "Recovery execution requires explicit -Confirm flag"
    }

    Write-Host "=============================================="
    Write-Host " HYSTAX RECOVERY WORKFLOW STARTED"
    Write-Host "Customer ID : $CustomerId"
    Write-Host "DR Plan     : $DRPlanName"
    Write-Host "Cloud Site  : $CloudSiteName"
    Write-Host "Mode        : $(if ($TestRecovery) { 'TEST RECOVERY' } else { 'FAILOVER' })"
    Write-Host "=============================================="

    # ------------------------------------------------------------
    # STEP 1: Fetch DR Plans
    # ------------------------------------------------------------
    Write-Host "Fetching DR plans..."
    $drPlansResponse = Get-HystaxDRPlans `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $drPlansResponse.plans) {
        throw "No DR plans returned for customer $CustomerId"
    }

    # ------------------------------------------------------------
    # STEP 2: Select DR Plan
    # ------------------------------------------------------------
    $drPlan = $drPlansResponse.plans |
              Where-Object { $_.name -eq $DRPlanName } |
              Select-Object -First 1

    if (-not $drPlan) {
        throw "DR plan '$DRPlanName' not found"
    }

    if (-not $drPlan.plan) {
        throw "Plan JSON missing for DR plan '$DRPlanName'"
    }

    Write-Host "Selected DR plan ID:" $drPlan.id

    # ------------------------------------------------------------
    # STEP 3: Deserialize Final Plan
    # ------------------------------------------------------------
    Write-Host "Deserializing DR plan..."
    $finalPlan = $drPlan.plan | ConvertFrom-Json

    # ------------------------------------------------------------
    # STEP 4: Print Final Plan (Verification)
    # ------------------------------------------------------------
    Write-Host "===== FINAL DR PLAN (JSON) ====="
    $finalPlan | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 5: Generate Recovery Timestamp (UTC Epoch)
    # ------------------------------------------------------------
    $timestamp = [int][double]::Parse((Get-Date -UFormat %s))
    Write-Host "Generated recovery timestamp:" $timestamp

    # ------------------------------------------------------------
    # STEP 6: Build Run Recovery Payload
    # ------------------------------------------------------------
    $payload = @{
        name             = $CloudSiteName
        customer_id      = $CustomerId
        timestamp        = $timestamp
        testsiterecovery = $(if ($TestRecovery) { "true" } else { "" })
        plan             = $finalPlan
    }

    Write-Host "===== RUN RECOVERY PAYLOAD ====="
    $payload | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 7: Execute Run Recovery (FORM POST, NOT JSON)
    # ------------------------------------------------------------
    Write-Host "🚀 Executing Run Recovery (form-based)..."

    $formBody = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $CloudSiteName
        customer_id         = $CustomerId
        timestamp           = $timestamp
        testsiterecovery    = $(if ($TestRecovery) { "true" } else { "" })
        plan                = ($finalPlan | ConvertTo-Json -Depth 15)
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)/ajax/run_recover/" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/recover_step_three/"
            } `
            -Body $formBody `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host " Run Recovery request submitted successfully"
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw " Recovery execution failed: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Wait for Hystax Cloud Validation (With Retry) ----------
function Wait-HystaxCloudValidation {
    # [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CloudId,

        [int]$WaitSeconds = 10,
        [int]$MaxAttempts = 2
    )

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {

        Write-Host "[INFO] Validation check attempt $attempt of $MaxAttempts"
        Write-Host "[INFO] Waiting $WaitSeconds seconds..."
        Start-Sleep -Seconds $WaitSeconds

        Write-Host "[INFO] Fetching cloud details..."
        $cloudsResponse = Get-HystaxClouds -Context $Context

        if (-not $cloudsResponse.clouds) {
            throw "[ERROR] No clouds returned from Get-HystaxClouds"
        }

        $cloud = $cloudsResponse.clouds |
                 Where-Object { $_.id -eq $CloudId } |
                 Select-Object -First 1

        if (-not $cloud) {
            throw "[ERROR] Cloud with ID '$CloudId' not found"
        }

        Write-Host "[INFO] Cloud Name        :" $cloud.name
        Write-Host "[INFO] Validation State :" $cloud.validation_state

        if ($cloud.validation_state -eq "validated") {
            Write-Host "[SUCCESS] Cloud validation completed successfully"
            return $true
        }

        if ($attempt -lt $MaxAttempts) {
            Write-Host "[WARN] Cloud validation still in progress, retrying..."
        }
    }

    # If we reach here, validation never succeeded
    throw "[ERROR] Cloud validation failed or did not complete after $MaxAttempts attempts"
}


# ----------------- Main script --------------------#


$baseUrl   = "https://172.21.71.176"
$partnerId = "4dae4ead-11bf-4f06-9a8e-b05c473be164"
$username  = "sadmin"
$password  = "Un1sys!12345"

# Initialize session
$ctx = Initialize-HystaxSession `
            -BaseUrl $baseUrl `
            -PartnerId $partnerId `
            -Username $username `
            -Password $password


# create target cloud
$newCloud = New-HystaxTargetCloud `
    -Context $ctx `
    -CloudName "DR_target_cloud_199_2" `
    -VCenterEndpoint "172.21.71.199" `
    -VCenterUsername "administrator@unisys.local" `
    -VCenterPassword "Un1sys!12345" `
    -EsxiHost "172.21.71.101" `
    -Datastore "local-host101"

$cloudId = $newCloud.id
Wait-HystaxCloudValidation `
    -Context $ctx `
    -CloudId $cloudId

# Wait-ForCloudValidation -Context $ctx -CloudId $cloudId

# # $response = Get-HystaxClouds -Context $ctx

# # $cloud = $response.clouds |
# #          Where-Object { $_.name -eq "DR_target_cloud_199" } |
# #          Select-Object -First 1

# # Wait-ForCloudValidation `
# #     -Context $ctx `
# #     -CloudId $cloud.id

# # ............ customer creation ..............
# New-HystaxCustomer `
#     -Context $ctx `
#     -CustomerName "test_pvt" `
#     -Email "abc@gmail.com" `
#     -CloudId $cloudId `
#     -Timezone "UTC"

# # List customers
# $customers = Get-HystaxCustomers -Context $ctx
# $customers | Format-Table -AutoSize

# # List clouds
# $clouds = Get-HystaxClouds -Context $ctx
# $clouds | Format-Table -AutoSize

# #................fetching machine group id............................
# $groups = Get-HystaxMachineGroups `
#             -Context $ctx `
#             -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa"

# $groups |
# Select-Object `
#     @{ Name = "id"; Expression = { $_.id } },
#     @{ Name = "name"; Expression = { $_.name } },
#     @{ Name = "description"; Expression = { $_.description } } |
# Format-Table -AutoSize

# #.........storing machine group id.................
# $groupName = "Default"

# $machineGroup = $groups | Where-Object {
#     $_.name -eq $groupName
# }

# if (-not $machineGroup) {
#     throw "Machine group '$groupName' not found"
# }

# $machineGroupId = $machineGroup.id
# # $machineGroupId 



# #...........list vm's...............
# $machines = Get-HystaxMachines `
#               -Context $ctx `
#               -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa" `
#               -MachineGroupId $machineGroupId

# $machines |
# Select-Object `
#     id,
#     name,
#     status,
#     status_level,
#     is_online,
#     group |
# Format-Table -AutoSize



# #............. new machine group  ...............
# $newGroup = New-HystaxMachineGroup `
#               -Context $ctx `
#               -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa" `
#               -GroupName "test_group" `
#               -Description "Group created via automation"

# Write-Host "Waiting 10 seconds for machine group creation..."
# Start-Sleep -Seconds 10

# # ............. fetching new machine group id ...........
# $groups = Get-HystaxMachineGroups `
#             -Context $ctx `
#             -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa"

# $groups |
# Select-Object `
#     @{ Name = "id"; Expression = { $_.id } },
#     @{ Name = "name"; Expression = { $_.name } },
#     @{ Name = "description"; Expression = { $_.description } } |
# Format-Table -AutoSize

# #.........storing machine group id.................
# $groupName = "test_group"

# $machineGroup = $groups | Where-Object {
#     $_.name -eq $groupName
# }

# if (-not $machineGroup) {
#     throw "Machine group '$groupName' not found"
# }

# $machineGroupId = $machineGroup.id

# # #........ moving vm's to machine group .....................
# # Move-HystaxMachineToGroup `
# #     -Context $ctx `
# #     -MachineId "5004d850-0308-8e80-b7e0-7dd0f39fe792" `
# #     -TargetGroupId $machineGroupId

# # Write-Host "Waiting 5 seconds for moving machine..."
# # Start-Sleep -Seconds 5

# #.......... moving multiple machines to new group .........
# $machineIds = @(
#     "500433df-ef5e-1c5d-bbbb-08644126cd66",
#     "50049c79-d5bf-00fe-ab32-4e53b2398a6a",
#     "5004379f-7a5d-ab20-b7a9-ada6863530ca"
# )

# Move-HystaxMachinesToGroup `
#     -Context $ctx `
#     -TargetGroupId $machineGroupId `
#     -MachineIds $machineIds

# Write-Host "Waiting 10 seconds for moving machines..."
# Start-Sleep -Seconds 10


# # ....................... start protection ...............

# Start-HystaxMachineProtection `
#     -Context $ctx `
#     -MachineId "500433df-ef5e-1c5d-bbbb-08644126cd66"


# #-------------------- LIST DR PLANS --------------------
 
# $drPlansResponse = Get-HystaxDRPlans `
#     -Context $ctx `
#     -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa"
 

# $drPlan = $drPlansResponse.plans |
#           Where-Object { $_.name -eq "final_drplan" } |
#           Select-Object -First 1

# if (-not $drPlan) {
#     throw "DR plan 'final_drplan' not found"
# }

# if (-not $drPlan.plan) {
#     throw "Plan JSON missing for DR plan $($drPlan.name)"
# }

# # Deserialize plan JSON
# $finalPlan = $drPlan.plan | ConvertFrom-Json
# Write-Host "FINAL PLAN JSON:"
# $finalPlan | ConvertTo-Json -Depth 10 | Write-Host
# Write-Host "`nDR Plans:"
# $drPlansResponse.plans |
#     Select-Object `
#         id,
#         name,
#         customer_id |
#     Format-Table -AutoSize

# Invoke-HystaxRecoveryWorkflow `
#     -Context $ctx `
#     -CustomerId "d2f35651-6e1d-4a26-a349-1e59d38975fa" `
#     -DRPlanName "final_drplan" `
#     -CloudSiteName "auto-failover-cloudsite-$(Get-Date -Format yyyyMMddHHmmss)" `
#     -Confirm
