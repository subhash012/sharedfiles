# ==================================================
# Hystax Acura DR – Main Script(phase 1)
# ==================================================

# Load configuration
. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
. (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")

# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# ---------- vCenter Credential ----------
$VCenterSecurePassword = ConvertTo-SecureString `
    $HystaxConfig.VCenterPassword `
    -AsPlainText `
    -Force

$VCenterCredential = New-Object pscredential (
    $HystaxConfig.VCenterUser,
    $VCenterSecurePassword
)


# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential


#Create New Target Cloud 
$newCloud = New-HystaxTargetCloud `
    -Context           $HystaxContext `
    -Config            $HystaxConfig `
    -CloudName         $HystaxConfig.CloudName `
    -VCenterEndpoint   $HystaxConfig.VCenterEndpoint `
    -VCenterCredential $VCenterCredential `
    -EsxiHost          $HystaxConfig.EsxiHost `
    -Datastore         $HystaxConfig.Datastore

$cloudId = $newCloud.id
Write-Host "[INFO] Target Cloud ID: $cloudId"

# cloud validation
Wait-HystaxCloudValidation `
    -Context $HystaxContext `
    -CloudId $cloudId `
    -Config $HystaxConfig


#Get Hystax Clouds
$clouds = Get-HystaxClouds -Context $HystaxContext
$clouds | Format-Table -AutoSize

#Customer Creation
$newCustomer = New-HystaxCustomer `
    -Context      $HystaxContext `
    -Config       $HystaxConfig `
    -CustomerName $HystaxConfig.customer_name `
    -Email        $HystaxConfig.customer_email `
    -CloudId      $cloudId

# List customers
$customers = Get-HystaxCustomers -Context $HystaxContext
$customers | Format-Table -AutoSize

