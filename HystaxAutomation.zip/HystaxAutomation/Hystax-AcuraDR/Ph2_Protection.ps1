# ==================================================
# Hystax Acura DR – Main Script(phase 2)
# ==================================================

. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
. (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")


# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# ---------- vCenter Credential ----------
$VCenterSecurePassword = ConvertTo-SecureString `
    $HystaxConfig.VCenterPassword `
    -AsPlainText `
    -Force

$VCenterCredential = New-Object pscredential (
    $HystaxConfig.VCenterUser,
    $VCenterSecurePassword
)

# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential

#fetching customer id
$customer_id = Get-HystaxCustomerId `
    -Context $HystaxContext `
    -CustomerName $HystaxConfig.customer_name

# Create Machine Group
$MachineGroupId = New-HystaxMachineGroup `
    -Context     $HystaxContext `
    -CustomerId  $customer_id `
    -GroupName   $HystaxConfig.MachineGroupName `
    -Description $HystaxConfig.MachineGroupDescription

Wait-HystaxMachineGroupCreation -WaitSeconds 10

# List MachineGroups 
$groups = Get-HystaxMachineGroups `
    -Context $HystaxContext `
    -CustomerId $customer_id

$groups |
Select-Object `
    @{ Name = "id"; Expression = { $_.id } },
    @{ Name = "name"; Expression = { $_.name } },
    @{ Name = "description"; Expression = { $_.description } } |
Format-Table -AutoSize

#getting machine ids
$groupId = Get-HystaxMachineGroupId `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -GroupName "Default"

$machineIds = Get-HystaxMachineIdsByNames `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -MachineGroupId $groupId `
    -MachineNames $HystaxConfig.machineNames

# $machineIds

# Move multiple machines to target group
Move-HystaxMachinesToGroup `
    -Context $HystaxContext `
    -TargetGroupId $MachineGroupId `
    -MachineIds $machineIds

# Optional wait
Wait-HystaxMachineMove -WaitSeconds 20

$result = Start-HystaxMachinesProtection `
    -Context $HystaxContext `
    -MachineIds $machineIds

# Wait for completion
$result = Wait-HystaxMachinesProtection `
    -Context $HystaxContext `
    -CustomerId $customer_id `
    -MachineGroupId $MachineGroupId `
    -MachineIds $machineIds `
    -PollIntervalMinutes 5            