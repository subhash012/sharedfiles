# ==================================================
# Hystax Acura DR – Main Script(phase 3)
# ==================================================

. (Join-Path $PSScriptRoot "Config\Hystax_Config.ps1")

# Load functions
. (Join-Path $PSScriptRoot "Functions\Hystax_functions.ps1")

# Convert password from config to SecureString
$SecurePassword = ConvertTo-SecureString `
    $HystaxConfig.HystaxPassword `
    -AsPlainText `
    -Force

# Create PSCredential object
$HystaxCredential = New-Object pscredential (
    $HystaxConfig.HystaxUser,
    $SecurePassword
)

# Initialize Hystax session
$HystaxContext = Initialize-HystaxSession `
    -BaseUrl   $HystaxConfig.BaseUrl `
    -PartnerId $HystaxConfig.PartnerId `
    -Credential $HystaxCredential


#fetching customer id
$customerId = Get-HystaxCustomerId `
    -Context $HystaxContext `
    -CustomerName $HystaxConfig.customer_name


$groupId = Get-HystaxMachineGroupId `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -GroupName $HystaxConfig.MachineGroupName



$machines = Get-HystaxMachines `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -MachineGroupId $groupId

if (-not $machines -or $machines.Count -eq 0) {
    throw "[ERROR] No machines found in machine group '$($HystaxConfig.MachineGroupName)'"
}



# --------------------------------------------------
# Build PLAN JSON
# --------------------------------------------------
$devices = @{}
$rank = 0

foreach ($m in $machines) {
    $devices[$m.name] = @{
        id     = $m.id
        flavor = $HystaxConfig.Flavor
        rank   = $rank
        ports  = @(
            @{
                name   = "port_0"
                subnet = $HystaxConfig.CloudSubnetName
            }
        )
    }
    $rank++
}

$planJson = @{
    devices = $devices
    subnets = @{
        $HystaxConfig.CloudSubnetName = @{
            name      = $HystaxConfig.CloudSubnetName
            subnet_id = $HystaxConfig.CloudSubnetName
            cidr      = $HystaxConfig.CloudSubnetCIDR
        }
    }
} | ConvertTo-Json -Depth 15 -Compress


# --------------------------------------------------
# Build ALL_PLANS
# --------------------------------------------------
$allPlansJson = @{
    devices = $devices
    subnets = @{
        subnet_0 = @{
            cidr = $HystaxConfig.CloudSubnetCIDR
        }
    }
} | ConvertTo-Json -Depth 10 -Compress

# --------------------------------------------------
# Build GROUPS
# --------------------------------------------------
$groupsJson = @(
    @{
        id          = $groupId
        customer_id = $customerId
        name        = $HystaxConfig.MachineGroupName
        machines    = $machines.id
    }
) | ConvertTo-Json -Depth 10 -Compress


# --------------------------------------------------
# Create DR Plan
# --------------------------------------------------
New-HystaxDRPlan `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -PlanName $HystaxConfig.DRPlanName

Create-HystaxDRPlan `
    -Context $HystaxContext `
    -CustomerId $customerId `
    -PlanName $HystaxConfig.DRPlanName `
    -PlanJson $planJson `
    -AllPlansJson $allPlansJson `
    -GroupsJson $groupsJson `
    -CloudType $HystaxConfig.DRPlanCloudType

Write-Host "`n===== PHASE 3 COMPLETED ====="
Write-Host "⏸ DR plan created. Failover execution is a separate controlled step."
 