# ==================================================
# Hystax Acura DR – Configuration
# ==================================================

$HystaxConfig = @{
    BaseUrl   = "https://172.21.71.176"
    PartnerId = "4dae4ead-11bf-4f06-9a8e-b05c473be164"

    # -------------------------------
    # Hystax UI credentials
    # -------------------------------
    HystaxUser     = "sadmin"
    HystaxPassword = "Un1sys!12345"

    # -------------------------------
    # vCenter Credentials
    # -------------------------------
    VCenterEndpoint = "172.21.71.199"
    VCenterUser     = "administrator@unisys.local"
    VCenterPassword = "Un1sys!12345"

    EsxiHost   = "172.21.71.101"
    Datastore = "local-host101"

    # -------------------------------
    # Target Cloud configuration
    # -------------------------------
    CloudName            = "Dr_test_cloud_2"
    TargetCloudType      = "vmware_cnr"
    MountpointVariant    = "mp_cloud_agent"
    AdditionalParameters = "{}"
    # -------------------------------
    # Cloud validation timing
    # -------------------------------
    CloudValidation = @{
       Attempts    = 2
       WaitSeconds = 10
    }

    # -------------------------------
    # Customer configuration
    # -------------------------------
    
    Timezone = "UTC"
    Active   = "on"
    Phone    = ""
    Address  = ""
    MountpointOverlay    = ""
    # customer_name = "test_pvt"
    customer_name = "customer_cc_hystax"
    customer_email = "customer@gamil.com"

   

    # -------------------------------
    # Machine Group configuration
    # -------------------------------

    MachineGroupName        = "automation_test_group"
    MachineGroupDescription = "Group created via automation"
    machineNames = @(
    "automation_test_01",
    "automation_test_02",
    "automation_test_03"
    )
  
    
    # -------------------------------
    # DR Plan configuration
    # -------------------------------
    DRPlanName = "DR_automation_test"

    DRPlanCloudType = "vmware_cnr"

    CloudSubnetName = "VM Network"
    CloudSubnetCIDR = "172.21.71.0/24"

    Flavor = "1-2"


    }