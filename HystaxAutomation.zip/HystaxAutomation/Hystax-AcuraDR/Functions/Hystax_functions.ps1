# ==================================================
# FUNCTION: Initialize-HystaxSession
# ==================================================
function Initialize-HystaxSession {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$BaseUrl,

        [Parameter(Mandatory)]
        [string]$PartnerId,

        [Parameter(Mandatory)]
        [pscredential]$Credential
    )

    Write-Host "[INFO] Initializing Hystax Acura DR session..."

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    $loginPage = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -WebSession $session `
        -UseBasicParsing

    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Credential.UserName
        password            = $Credential.GetNetworkCredential().Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "[SUCCESS] Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}
# --------------------------------------------------
# FUNCTION: Invoke-HystaxApiRequest
# --------------------------------------------------
function Invoke-HystaxApiRequest {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$RelativeUrl,

        [ValidateSet("GET","POST","PUT","DELETE")]
        [string]$Method = "POST",

        [object]$Body
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri        = "$($Context.BaseUrl)$RelativeUrl"
        Method     = $Method
        WebSession = $Context.Session
        Headers    = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    try {
        $response = Invoke-WebRequest @params
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Hystax API request failed [$RelativeUrl]: $_"
    }
}


# ==================================================
# FUNCTION: New-HystaxTargetCloud
# ==================================================
function New-HystaxTargetCloud {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [hashtable]$Config,

        [Parameter(Mandatory)]
        [string]$CloudName,

        [Parameter(Mandatory)]
        [string]$VCenterEndpoint,

        [Parameter(Mandatory)]
        [pscredential]$VCenterCredential,

        [Parameter(Mandatory)]
        [string]$EsxiHost,

        [Parameter(Mandatory)]
        [string]$Datastore
    )

    Write-Host "[INFO] Creating target cloud: $CloudName"

    $payload = @{
        csrfmiddlewaretoken   = $Context.CsrfToken
        type                  = $Config.TargetCloudType
        name                  = $CloudName
        endpoint              = $VCenterEndpoint
        username              = $VCenterCredential.UserName
        password              = $VCenterCredential.GetNetworkCredential().Password
        vmware_host           = $EsxiHost
        vmware_datastore      = $Datastore
        mountpoint_variant    = $Config.MountpointVariant
        additional_parameters = $Config.AdditionalParameters
        cloud_form_url        = "/partner/$($Context.PartnerId)/clouds/cloud-add-form/"
    }

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/partner/$($Context.PartnerId)/clouds/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/clouds/"
        } `
        -Body $payload `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    Write-Host "[SUCCESS] Target cloud created successfully"
    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: Get-HystaxClouds
# ==================================================
function Get-HystaxClouds {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching clouds..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/clouds/list/"

    if (-not $result.clouds) {
        Write-Warning "[WARN] No clouds returned from Get-HystaxClouds"
        return @()
    }

    return $result.clouds
}


# ---------- FUNCTION: Wait for Hystax Cloud Validation (With Retry) ----------
# function Wait-HystaxCloudValidation {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory)]
#         [hashtable]$Context,

#         [Parameter(Mandatory)]
#         [string]$CloudId,

#         [int]$WaitSeconds = 10,
#         [int]$MaxAttempts = 2
#     )

#     for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {

#         Write-Host "[INFO] Validation check attempt $attempt of $MaxAttempts"
#         Write-Host "[INFO] Waiting $WaitSeconds seconds..."
#         Start-Sleep -Seconds $WaitSeconds

#         Write-Host "[INFO] Fetching cloud details..."
#         $cloudsResponse = Get-HystaxClouds -Context $Context

#         if (-not $cloudsResponse.clouds) {
#             throw "[ERROR] No clouds returned from Get-HystaxClouds"
#         }

#         $cloud = $cloudsResponse.clouds |
#                  Where-Object { $_.id -eq $CloudId } |
#                  Select-Object -First 1

#         if (-not $cloud) {
#             throw "[ERROR] Cloud with ID '$CloudId' not found"
#         }

#         Write-Host "[INFO] Cloud Name        :" $cloud.name
#         Write-Host "[INFO] Validation State :" $cloud.validation_state

#         if ($cloud.validation_state -eq "validated") {
#             Write-Host "[SUCCESS] Cloud validation completed successfully"
#             return $true
#         }

#         if ($attempt -lt $MaxAttempts) {
#             Write-Host "[WARN] Cloud validation still in progress, retrying..."
#         }
#     }

#     # If we reach here, validation never succeeded
#     throw "[ERROR] Cloud validation failed or did not complete after $MaxAttempts attempts"
# }

# ==================================================
# FUNCTION: Wait-HystaxCloudValidation
# Purpose : Validate cloud with limited wait
# ==================================================
function Wait-HystaxCloudValidation {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CloudId,

        [Parameter(Mandatory)]
        [hashtable]$Config
    )

    $attempts    = $Config.CloudValidation.Attempts
    $waitSeconds = $Config.CloudValidation.WaitSeconds

    for ($i = 1; $i -le $attempts; $i++) {

        Write-Host "[INFO] Waiting $waitSeconds seconds before checking cloud validation (Attempt $i/$attempts)..."
        Start-Sleep -Seconds $waitSeconds

        $cloud = (Get-HystaxClouds -Context $Context) |
                 Where-Object { $_.id -eq $CloudId }

        if (-not $cloud) {
            throw "[ERROR] Cloud with ID '$CloudId' not found"
        }

        Write-Host "[INFO] Cloud '$($cloud.name)' validation state: $($cloud.validation_state)"

        if ($cloud.validation_state -in @("valid", "validated")) {
            Write-Host "[SUCCESS] Cloud validated successfully"
            return
        }
    }

    throw "[ERROR] Cloud '$CloudId' not validated after $($attempts * $waitSeconds) seconds"
}
# ==================================================
# FUNCTION: Get-HystaxCloudValidationState
# ==================================================

# function Wait-HystaxCloudValidation {
#     [CmdletBinding()]
#     param (
#         [Parameter(Mandatory)]
#         [int]$WaitSeconds
#     )

#     Write-Host "[INFO] Waiting for cloud validation..."
#     Start-Sleep -Seconds $WaitSeconds
#     Write-Host "[SUCCESS] Cloud validation successful"
# }

# ==================================================
# FUNCTION: Creates New Customer
# ==================================================

function New-HystaxCustomer {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [hashtable]$Config,

        [Parameter(Mandatory)]
        [string]$CustomerName,

        [Parameter(Mandatory)]
        [string]$Email,

        [Parameter(Mandatory)]
        [string]$CloudId
    )

    Write-Host "[INFO] Creating customer: $CustomerName"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken

        name      = $CustomerName
        email     = $Email
        phone     = $Config.Phone
        address   = $Config.Address
        timezone  = $Config.Timezone

        active    = $Config.Active
        cloud     = $CloudId

        is_openstack_cloud = "{`"$CloudId`": false}"
        
        additional_parameters = $Config.AdditionalParameters
        mountpoint_overlay    = $Config.MountpointOverlay
       
    }

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/partner/$($Context.PartnerId)/customer/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/partner/$($Context.PartnerId)/customers/"
        } `
        -Body $payload `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing

    Write-Host "[SUCCESS] Customer created successfully"
    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: Get-HystaxCustomers
# ==================================================
function Get-HystaxCustomers {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context
    )

    Write-Host "[INFO] Fetching customers..."

    $result = Invoke-HystaxApiRequest `
        -Context     $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/" 

    return $result.customers
}

# ---------- FUNCTION: Get Hystax Customer ID ----------
function Get-HystaxCustomerId {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerName
    )

    Write-Host "[INFO] Fetching customer ID for customer name: '$CustomerName'"

    $customer = Get-HystaxCustomers -Context $Context |
                Where-Object { $_.customer_name -eq $CustomerName } |
                Select-Object -First 1

    if (-not $customer) {
        throw "Customer '$CustomerName' not found"
    }

    Write-Host "[INFO] Customer '$CustomerName' resolved with ID: $($customer.customer_id)"

    return $customer.customer_id
}

# ==================================================
# FUNCTION: Create Machine Group
# ==================================================
# ---------- FUNCTION: Create Hystax Machine Group ----------
function New-HystaxMachineGroup {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName,

        [string]$Description
    )

    Write-Host "[INFO] Creating machine group '$GroupName' for customer $CustomerId..."

    $relativeUrl = "/customer/$CustomerId/group/add/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $GroupName
        description         = $Description
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        if (-not $response.Content) {
            throw "Empty response received while creating machine group"
        }

        $group = $response.Content | ConvertFrom-Json

        if (-not $group.id) {
            throw "Machine group ID not found in response"
        }

        Write-Host "[INFO] Machine group '$GroupName' created with ID: $($group.id)"

        return $group.id
    }
    catch {
        throw "Failed to create machine group '$GroupName': $($_.Exception.Message)"
    }
}


# ==================================================
# FUNCTION: Wait-HystaxMachineGroupCreation
# Purpose : Simple wait after machine group creation
# ==================================================
function Wait-HystaxMachineGroupCreation {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [int]$WaitSeconds
    )

    Write-Host "[INFO] Waiting for machine group creation..."
    Start-Sleep -Seconds $WaitSeconds
    Write-Host "[SUCCESS] Machine group created successfully"
}

# ==================================================
# FUNCTION: Get-HystaxMachineGroups
# Purpose : List machine groups for a customer
# ==================================================
function Get-HystaxMachineGroups {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching machine groups for customer: $CustomerId"

    $relativeUrl = "/customer/$CustomerId/group/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw "Failed to list machine groups for customer '$CustomerId': $($_.Exception.Message)"
    }
}

# ==================================================
# FUNCTION: Get-HystaxMachines
# Purpose : List machines (VMs) from a machine group
# ==================================================
function Get-HystaxMachines {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId
    )

    Write-Host "[INFO] Fetching machines for group $MachineGroupId ..."

    $relativeUrl = "/customer/$CustomerId/group/$MachineGroupId/machines/list/"

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-CSRFToken"       = $Context.CsrfToken
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
            } `
            -UseBasicParsing

        $result = $response.Content | ConvertFrom-Json

        if (-not $result.machines) {
            Write-Host "[WARN] No machines found in this group"
            return @()
        }

        return $result.machines
    }
    catch {
        throw "Failed to list machines: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Get Hystax Machine IDs by Machine Names (Non-blocking) ----------
function Get-HystaxMachineIdsByNames {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineNames
    )

    Write-Host "[INFO] Fetching machines for group ID: $MachineGroupId"

    $machines = Get-HystaxMachines `
        -Context $Context `
        -CustomerId $CustomerId `
        -MachineGroupId $MachineGroupId

    if (-not $machines -or $machines.Count -eq 0) {
        Write-Warning "No machines found in group '$MachineGroupId'"
        return @()
    }

    $machineIds = @()
    $notFound   = @()

    foreach ($name in $MachineNames) {
        $machine = $machines |
                   Where-Object { $_.name -eq $name } |
                   Select-Object -First 1

        if ($machine) {
            Write-Host "[INFO] Found VM '$name' → ID: $($machine.id)"
            $machineIds += $machine.id
        }
        else {
            $notFound += $name
        }
    }

    if ($notFound.Count -gt 0) {
        Write-Warning "[WARN] The following VMs were NOT found in group '$MachineGroupId':"
        $notFound | ForEach-Object { Write-Warning "  - $_" }
    }

    if ($machineIds.Count -eq 0) {
        Write-Warning "[WARN] No valid machines resolved. Returning empty list."
    }

    return $machineIds
}


# ---------- FUNCTION: Get Hystax Machine Group ID ----------
function Get-HystaxMachineGroupId {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$GroupName
    )

    Write-Host "[INFO] Resolving machine group ID for group name: '$GroupName'"

    $groups = Get-HystaxMachineGroups `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $groups) {
        throw "No machine groups returned for customer '$CustomerId'"
    }

    $group = $groups |
             Where-Object { $_.name -eq $GroupName } |
             Select-Object -First 1

    if (-not $group) {
        throw "Machine group '$GroupName' not found for customer '$CustomerId'"
    }

    Write-Host "[INFO] Machine group '$GroupName' resolved with ID: $($group.id)"

    return $group.id
}

# ==================================================
# FUNCTION: Move-HystaxMachineToGroup
# Purpose : Move a single VM to a machine group
# ==================================================
function Move-HystaxMachineToGroup {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [Parameter(Mandatory)]
        [string]$TargetGroupId
    )

    Write-Host "[INFO] Moving machine '$MachineId' to group '$TargetGroupId'..."

    $relativeUrl = "/machine/$MachineId/move/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        group               = $TargetGroupId
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing
    }
    catch {
        throw "Failed to move machine '$MachineId': $($_.Exception.Message)"
    }
}

# ==================================================
# FUNCTION: Wait-HystaxMachineMove
# Purpose : Wait for machine move to reflect in UI
# ==================================================
function Wait-HystaxMachineMove {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [int]$WaitSeconds
    )

    Write-Host "[INFO] Waiting for machine move to complete..."
    Start-Sleep -Seconds $WaitSeconds
    Write-Host "[SUCCESS] Machines moved Successfully"
}

# ==================================================
# FUNCTION: Move Multiple VMs to a Group
# ==================================================
function Move-HystaxMachinesToGroup {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$TargetGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineIds
    )

    Write-Host "[INFO] Starting bulk move of $($MachineIds.Count) machine(s)..."

    foreach ($machineId in $MachineIds) {
        try {
            Move-HystaxMachineToGroup `
                -Context $Context `
                -MachineId $machineId `
                -TargetGroupId $TargetGroupId
        }
        catch {
            throw "[ERROR] Bulk move failed for machine $machineId : $($_.Exception.Message)"
        }
    }
}

function Start-HystaxMachineProtection {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$MachineId,

        [switch]$ForceFullReplication
    )

    Write-Host "[INFO] Starting protection for machine '$MachineId'..."

    $relativeUrl = "/machine/$MachineId/unpark/"

    $payload = @{
        csrfmiddlewaretoken = $Context.CsrfToken
    }

    if ($ForceFullReplication.IsPresent) {
        $payload["force_full"] = "true"
        Write-Host "[WARN] Force full replication enabled"
    }

    try {
        Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)$relativeUrl" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/customer/"
            } `
            -Body $payload `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host "[SUCCESS] Protection started successfully"
    }
    catch {
        throw "Failed to start protection for machine ${MachineId}: $($_.Exception.Message)"
    }
}

# ---------- FUNCTION: Start Protection for Multiple Machines ----------
function Start-HystaxMachinesProtection {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string[]]$MachineIds,

        [switch]$ForceFullReplication
    )

    Write-Host "[INFO] Starting protection for $($MachineIds.Count) machine(s)..."

    $failedMachines = @()

    foreach ($machineId in $MachineIds) {
        try {
            if ($ForceFullReplication.IsPresent) {
                Start-HystaxMachineProtection `
                    -Context $Context `
                    -MachineId $machineId `
                    -ForceFullReplication
            }
            else {
                Start-HystaxMachineProtection `
                    -Context $Context `
                    -MachineId $machineId
            }
            Start-Sleep -Seconds 20
        }
        catch {
            Write-Warning "[WARN] Failed to start protection for machine $machineId"
            Write-Warning $_.Exception.Message
            $failedMachines += $machineId
        }
    }

    if ($failedMachines.Count -gt 0) {
        Write-Warning "[SUMMARY] Protection failed for the following machines:"
        $failedMachines | ForEach-Object { Write-Warning "  - $_" }
    }
    else {
        Write-Host "[SUCCESS] Protection started successfully for all machines"
    }

    return @{
        TotalRequested = $MachineIds.Count
        FailedMachines = $failedMachines
        Successful     = $MachineIds.Count - $failedMachines.Count
    }
}

# ---------- FUNCTION: Wait for Hystax Machines Protection ----------
function Wait-HystaxMachinesProtection {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$MachineGroupId,

        [Parameter(Mandatory)]
        [string[]]$MachineIds,

        [int]$PollIntervalMinutes = 5,

        [int]$MaxWaitMinutes = 720   # 12 hours safety cap
    )

    Write-Host "[INFO] Waiting for machines to reach terminal state (Protected / Parked)..."
    Write-Host "[INFO] Poll interval: $PollIntervalMinutes minutes"
    Write-Host "[INFO] Max wait time: $MaxWaitMinutes minutes"

    $elapsedMinutes = 0
    $terminalStates = @("protected", "parked")

    while ($true) {

        Write-Host "`n[INFO] Polling machine status (Elapsed: $elapsedMinutes min)..."

        $machines = Get-HystaxMachines `
            -Context $Context `
            -CustomerId $CustomerId `
            -MachineGroupId $MachineGroupId

        # Filter only machines we care about
        $trackedMachines = $machines |
                           Where-Object { $MachineIds -contains $_.id }

        if (-not $trackedMachines -or $trackedMachines.Count -eq 0) {
            Write-Warning "[WARN] None of the tracked machines found in group"
            break
        }

        $pending = @()

        foreach ($machine in $trackedMachines) {

            $state = $machine.status_level.ToLower()
            $progress = if ($machine.progress) { "$($machine.progress)%" } else { "N/A" }

            Write-Host (" - {0,-25} | State: {1,-12} | Progress: {2}" -f `
                $machine.name, $state, $progress)

            if ($terminalStates -notcontains $state) {
                $pending += $machine
            }
        }

        if ($pending.Count -eq 0) {
            Write-Host "`n[SUCCESS] All machines reached terminal state"
            return @{
                Status = "Completed"
                Machines = $trackedMachines
            }
        }

        if ($elapsedMinutes -ge $MaxWaitMinutes) {
            Write-Warning "[TIMEOUT] Maximum wait time reached"
            return @{
                Status = "TimedOut"
                PendingMachines = $pending
            }
        }

        Write-Host "[INFO] Waiting $PollIntervalMinutes minutes before next check..."
        Start-Sleep -Seconds ($PollIntervalMinutes * 60)
        $elapsedMinutes += $PollIntervalMinutes
    }
}

# ==================================================
# FUNCTION: Get-HystaxDRPlans
# Purpose : List DR plans for a customer
# ==================================================
function Get-HystaxDRPlans {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId
    )

    Write-Host "[INFO] Fetching DR plans for customer $CustomerId..."

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/list/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing

    return ($response.Content | ConvertFrom-Json)
}

# ==================================================
# FUNCTION: New-HystaxDRPlan (Template creation)
# ==================================================
function New-HystaxDRPlan {
    [CmdletBinding()]
    param (
        [hashtable]$Context,
        [string]$CustomerId,
        [string]$PlanName
    )

    Write-Host "[INFO] Creating DR plan template '$PlanName'..."

    Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/template/add/" `
        -Method POST `
        -WebSession $Context.Session `
        -Body @{
            csrfmiddlewaretoken = $Context.CsrfToken
            plan_name           = $PlanName
        } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing | Out-Null
}

# ==================================================
# FUNCTION: Create-HystaxDRPlan (DR Plan Creation)
# ==================================================
function Create-HystaxDRPlan {
    [CmdletBinding()]
    param (
        [hashtable]$Context,
        [string]$CustomerId,
        [string]$PlanName,
        [string]$PlanJson,
        [string]$AllPlansJson,
        [string]$GroupsJson,
        [string]$CloudType
    )

    Write-Host "[INFO] Creating DR plan '$PlanName'..."

    Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/create/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
        } `
        -Body @{
            csrfmiddlewaretoken = $Context.CsrfToken
            plan_name           = $PlanName
            plan                = $PlanJson
            all_plans           = $AllPlansJson
            groups              = $GroupsJson
            cloud_type          = $CloudType
        } `
        -ContentType "application/x-www-form-urlencoded" `
        -UseBasicParsing | Out-Null

    Write-Host "[SUCCESS] DR plan created successfully"
}

# -------------------------------
# FUNCTION:  Failover /  Recovery
# -------------------------------
function Invoke-HystaxRecoveryWorkflow {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$Context,

        [Parameter(Mandatory)]
        [string]$CustomerId,

        [Parameter(Mandatory)]
        [string]$DRPlanName,

        [Parameter(Mandatory)]
        [string]$CloudSiteName,

        [switch]$TestRecovery,
        [switch]$Confirm
    )

    if (-not $Confirm) {
        throw "Recovery execution requires explicit -Confirm flag"
    }

    Write-Host "=============================================="
    Write-Host " HYSTAX RECOVERY WORKFLOW STARTED"
    Write-Host "Customer ID : $CustomerId"
    Write-Host "DR Plan     : $DRPlanName"
    Write-Host "Cloud Site  : $CloudSiteName"
    Write-Host "Mode        : $(if ($TestRecovery) { 'TEST RECOVERY' } else { 'FAILOVER' })"
    Write-Host "=============================================="

    # ------------------------------------------------------------
    # STEP 1: Fetch DR Plans
    # ------------------------------------------------------------
    Write-Host "Fetching DR plans..."
    $drPlansResponse = Get-HystaxDRPlans `
        -Context $Context `
        -CustomerId $CustomerId

    if (-not $drPlansResponse.plans) {
        throw "No DR plans returned for customer $CustomerId"
    }

    # ------------------------------------------------------------
    # STEP 2: Select DR Plan
    # ------------------------------------------------------------
    $drPlan = $drPlansResponse.plans |
              Where-Object { $_.name -eq $DRPlanName } |
              Select-Object -First 1

    if (-not $drPlan) {
        throw "DR plan '$DRPlanName' not found"
    }

    if (-not $drPlan.plan) {
        throw "Plan JSON missing for DR plan '$DRPlanName'"
    }

    Write-Host "Selected DR plan ID:" $drPlan.id

    # ------------------------------------------------------------
    # STEP 3: Deserialize Final Plan
    # ------------------------------------------------------------
    Write-Host "Deserializing DR plan..."
    $finalPlan = $drPlan.plan | ConvertFrom-Json

    # ------------------------------------------------------------
    # STEP 4: Print Final Plan (Verification)
    # ------------------------------------------------------------
    Write-Host "===== FINAL DR PLAN (JSON) ====="
    $finalPlan | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 5: Generate Recovery Timestamp (UTC Epoch)
    # ------------------------------------------------------------
    $timestamp = [int][double]::Parse((Get-Date -UFormat %s))
    Write-Host "Generated recovery timestamp:" $timestamp

    # ------------------------------------------------------------
    # STEP 6: Build Run Recovery Payload
    # ------------------------------------------------------------
    $payload = @{
        name             = $CloudSiteName
        customer_id      = $CustomerId
        timestamp        = $timestamp
        testsiterecovery = $(if ($TestRecovery) { "true" } else { "" })
        plan             = $finalPlan
    }

    Write-Host "===== RUN RECOVERY PAYLOAD ====="
    $payload | ConvertTo-Json -Depth 15 | Write-Host
    Write-Host "================================"

    # ------------------------------------------------------------
    # STEP 7: Execute Run Recovery (FORM POST, NOT JSON)
    # ------------------------------------------------------------
    Write-Host " Executing Run Recovery (form-based)..."

    $formBody = @{
        csrfmiddlewaretoken = $Context.CsrfToken
        name                = $CloudSiteName
        customer_id         = $CustomerId
        timestamp           = $timestamp
        testsiterecovery    = $(if ($TestRecovery) { "true" } else { "" })
        plan                = ($finalPlan | ConvertTo-Json -Depth 15)
    }

    try {
        $response = Invoke-WebRequest `
            -Uri "$($Context.BaseUrl)/ajax/run_recover/" `
            -Method POST `
            -WebSession $Context.Session `
            -Headers @{
                "X-Requested-With" = "XMLHttpRequest"
                "Referer"          = "$($Context.BaseUrl)/recover_step_three/"
            } `
            -Body $formBody `
            -ContentType "application/x-www-form-urlencoded" `
            -UseBasicParsing

        Write-Host " Run Recovery request submitted successfully"
        return ($response.Content | ConvertFrom-Json)
    }
    catch {
        throw " Recovery execution failed: $($_.Exception.Message)"
    }
}