# hystax-list-clouds-fixed.ps1

$baseUrl = "https://172.21.71.176"
$partnerId = "4dae4ead-11bf-4f06-9a8e-b05c473be164"   # Replace with your Partner ID
$user = "sadmin"
$pass = "Un1sys!12345"
$logFile = "C:\HystaxAutomation\hystax-list-clouds.log"

Start-Transcript -Path $logFile -Append
Write-Host "[$(Get-Date)] Starting Hystax cloud listing..."

# Force TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Ignore SSL certificate errors
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

# Create web session
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

# Get login page and CSRF token
$loginPage = Invoke-WebRequest -Uri "$baseUrl/login/" -WebSession $session -UseBasicParsing
$csrfToken = [regex]::Match($loginPage.Content, 'name="csrfmiddlewaretoken" value="(.+?)"').Groups[1].Value

if (-not $csrfToken) { 
    Write-Host "Failed to extract CSRF token" 
    Stop-Transcript
    exit 
}
Write-Host "CSRF Token: $csrfToken"

# Submit login form
$formFields = @{
    csrfmiddlewaretoken = $csrfToken
    user_login          = $user
    password            = $pass
}
$response = Invoke-WebRequest `
    -Uri "$baseUrl/login/" `
    -Method POST `
    -Body $formFields `
    -WebSession $session `
    -ContentType "application/x-www-form-urlencoded" `
    -Headers @{ "Referer" = "$baseUrl/login/" } `
    -UseBasicParsing

if ($response.RawContent -match "login_form") {
    Write-Host "Authentication FAILED"
    Stop-Transcript
    exit
}
Write-Host "Authentication SUCCESS, session cookie obtained"

# List clouds
$cloudsUrl = "$baseUrl/partner/$partnerId/clouds/list/"

try {
    $headers = @{
        "X-CSRFToken" = $csrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer" = "$baseUrl/login/"
    }

    $cloudsResponse = Invoke-WebRequest `
        -Uri $cloudsUrl `
        -Method POST `
        -WebSession $session `
        -Headers $headers `
        -UseBasicParsing

    $clouds = $cloudsResponse.Content | ConvertFrom-Json
    Write-Host "Clouds retrieved successfully:"
    $clouds | Format-Table -AutoSize
}
catch {
    Write-Host "Failed to retrieve clouds:"
    Write-Host $_.Exception.Message
}

Stop-Transcript
