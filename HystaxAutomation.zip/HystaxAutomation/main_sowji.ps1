############################################################
# Hystax Automation – Single File
# Step 1: Authenticate
# Step 2: List Clouds
# Step 3: List Customers
# Step 4: List Machine Groups
# Step 5: Get Hystax Machines
# Step 6: Get Restore Points
############################################################

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------- FUNCTION: Initialize Hystax Session ----------
function Initialize-HystaxSession {
    param (
        [Parameter(Mandatory)][string]$BaseUrl,
        [Parameter(Mandatory)][string]$PartnerId,
        [Parameter(Mandatory)][string]$Username,
        [Parameter(Mandatory)][string]$Password
    )

    Write-Host "Initializing Hystax session..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    $loginPage = Invoke-WebRequest -Uri "$BaseUrl/login/" -WebSession $session -UseBasicParsing
    $csrfToken = [regex]::Match(
        $loginPage.Content,
        'name="csrfmiddlewaretoken" value="(.+?)"'
    ).Groups[1].Value

    if (-not $csrfToken) {
        throw "Failed to extract CSRF token"
    }

    $loginBody = @{
        csrfmiddlewaretoken = $csrfToken
        user_login          = $Username
        password            = $Password
    }

    $loginResponse = Invoke-WebRequest `
        -Uri "$BaseUrl/login/" `
        -Method POST `
        -Body $loginBody `
        -WebSession $session `
        -ContentType "application/x-www-form-urlencoded" `
        -Headers @{ Referer = "$BaseUrl/login/" } `
        -UseBasicParsing

    if ($loginResponse.RawContent -match "login_form") {
        throw "Authentication failed"
    }

    Write-Host "Authentication successful"

    return @{
        BaseUrl   = $BaseUrl
        PartnerId = $PartnerId
        Session   = $session
        CsrfToken = $csrfToken
    }
}

# ---------- FUNCTION: Invoke Hystax UI Request ----------
function Invoke-HystaxRequest {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$RelativeUrl,
        [string]$Method = "POST",
        [object]$Body = $null
    )

    $headers = @{
        "X-CSRFToken"       = $Context.CsrfToken
        "X-Requested-With" = "XMLHttpRequest"
        "Referer"          = "$($Context.BaseUrl)/login/"
    }

    $params = @{
        Uri            = "$($Context.BaseUrl)$RelativeUrl"
        Method         = $Method
        WebSession     = $Context.Session
        Headers        = $headers
        UseBasicParsing = $true
    }

    if ($Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 5)
        $params.ContentType = "application/json"
    }

    $response = Invoke-WebRequest @params
    return ($response.Content | ConvertFrom-Json)
}

# ---------- FUNCTION: Get Clouds ----------
function Get-HystaxClouds {
    param ([hashtable]$Context)
    Write-Host "Fetching clouds..."
    Invoke-HystaxRequest `
        -Context $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/clouds/list/"
}

# ---------- FUNCTION: Get Customers ----------
function Get-HystaxCustomers {
    param ([hashtable]$Context)
    Write-Host "Fetching customers..."
    $result = Invoke-HystaxRequest `
        -Context $Context `
        -RelativeUrl "/partner/$($Context.PartnerId)/customers/"
    return $result.customers
}

# ---------- FUNCTION: Get Machine Groups ----------
function Get-HystaxMachineGroups {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$CustomerId
    )

    Write-Host "Fetching machine groups for customer $CustomerId..."

    $relativeUrl = "/customer/$CustomerId/group/list/"

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)$relativeUrl" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
        } `
        -UseBasicParsing

    if ($response.Content -match "<html") {
        throw "HTML returned instead of JSON while listing machine groups"
    }

    # NOTE: this endpoint returns an ARRAY directly
    return ($response.Content | ConvertFrom-Json)
}

# ---------- FUNCTION: Get Machines ----------
function Get-HystaxMachines {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$CustomerId,
        [Parameter(Mandatory)][string]$MachineGroupId
    )

    Write-Host "Fetching machines for group $MachineGroupId..."

    $relativeUrl = "/customer/$CustomerId/group/$MachineGroupId/machines/list/"

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)$relativeUrl" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/"
        } `
        -UseBasicParsing

    $result = $response.Content | ConvertFrom-Json
    return $result.machines
}


function Get-HystaxDRPlans {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$CustomerId
    )

    Write-Host "Fetching DR plans for customer $CustomerId..."

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)/customer/$CustomerId/plan/list/" `
        -Method POST `
        -WebSession $Context.Session `
        -Headers @{
            "X-CSRFToken"       = $Context.CsrfToken
            "X-Requested-With" = "XMLHttpRequest"
            "Referer"          = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing

    return ($response.Content | ConvertFrom-Json)
}

function Get-HystaxDRPlanAddPage {
    param (
        [Parameter(Mandatory)][hashtable]$Context,
        [Parameter(Mandatory)][string]$CustomerId
    )

    Write-Host "Loading DR Plan Add page"

    $url = "/customer/$CustomerId/plan/add/"

    $response = Invoke-WebRequest `
        -Uri "$($Context.BaseUrl)$url" `
        -Method GET `
        -WebSession $Context.Session `
        -Headers @{
            "Referer" = "$($Context.BaseUrl)/customer/$CustomerId/plan/"
        } `
        -UseBasicParsing

    if ($response.StatusCode -ne 200) {
        throw "Failed to load DR Plan Add page"
    }

    Write-Host "DR Plan Add page loaded successfully"
    return $true
}


  
    




# -------------------- MAIN SCRIPT -------------------- #

$baseUrl   = "https://172.21.71.176"
$partnerId = "4dae4ead-11bf-4f06-9a8e-b05c473be164"
$username  = "sadmin"
$password  = "Un1sys!12345"

# Step 1: Authenticate
$ctx = Initialize-HystaxSession `
    -BaseUrl $baseUrl `
    -PartnerId $partnerId `
    -Username $username `
    -Password $password

# Step 2: List Clouds
$clouds = Get-HystaxClouds -Context $ctx
Write-Host "Clouds retrieved successfully:"
$clouds | Format-Table -AutoSize

# Step 3: List Customers
$customers = Get-HystaxCustomers -Context $ctx
Write-Host "Customers retrieved successfully:"
$customers | Format-Table -AutoSize

# Step 4: Pick first customer and list machine groups
$customerId = $customers[1].customer_id
Write-Host "Using Customer ID: $customerId"

$machineGroups = Get-HystaxMachineGroups `
    -Context $ctx `
    -CustomerId $customerId

Write-Host "Machine Groups retrieved successfully:"
$machineGroups |
    Select-Object id, name, description |
    Format-Table -AutoSize

# Step 5: List Machines From a Group
$machineGroupId = $machineGroups[0].id
$machines = Get-HystaxMachines `
    -Context $ctx `
    -CustomerId $customerId `
    -MachineGroupId $machineGroupId

Write-Host "Machines retrieved successfully:"
$machines |
    Select-Object `
        id,
        name,
        status,
        status_level,
        is_online,
        group |
    Format-Table -AutoSize


# -------------------- LIST DR PLANS --------------------

$drPlansResponse = Get-HystaxDRPlans `
    -Context $ctx `
    -CustomerId $customerId

Write-Host "`nDR Plans:"

$drPlansResponse.plans |
    Select-Object `
        id,
        name,
        customer_id |
    Format-Table -AutoSize


Get-HystaxDRPlanAddPage `
    -Context $ctx `
    -CustomerId $customerId

